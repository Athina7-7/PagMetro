<?php
include('menu.php');
?>


    <div class="content-wrapper">
        <section>
            <h2 style="position: relative; bottom: 40px;">Preguntas frecuentes</h2>

            <img src="https://d2yoo3qu6vrk5d.cloudfront.net/images/20190529121439/disencc83o-sin-titulo-41-1.png" alt=""
                style="position: relative; bottom: 50px;">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Sapiente sint voluptatibus deleniti quidem laudantium et
                omnis modi enim fuga alias, doloribus ullam eius pariatur,
                at ipsam? Commodi eveniet nulla ea!</p>

            <img src="https://sintrametro.com/wp-content/uploads/2019/01/Bolet%C3%ADn-a-los-Usuarios-2-730x450.jpeg"
                alt="imagen del metro">
            <h4>Nos preocupamos por nuestros usuarios</h4>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi aliquid placeat, quas ducimus rem
                architecto
                unde maxime? Provident nostrum soluta, repellat blanditiis ea sit, reiciendis vel consectetur, harum
                aspernatur magnam!</p>
        </section>
        <section id="sectionDerecha">
            <h4>Dicen</h4>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident earum est dolorem laudantium, labore
                quisquam. Aliquam nostrum expedita omnis commodi est aut doloremque atque odit! Cupiditate excepturi
                voluptate deserunt eligendi?</p>
            <img src="https://estaticos.elcolombiano.com/binrepository/780x565/0c0/780d565/none/11101/LUAK/cemetro-10-42334602-20230509061935_43753915_20231115082916.jpg"
                alt="imgPoblado">

            <h4>Estamos con ustedes</h4>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid iste libero quo odio, nesciunt quaerat
                nobis quia quos voluptatibus error accusamus? Blanditiis tempore placeat laudantium, ipsa sint ad labore
                itaque!</p>
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdyNVkFKjuY9cCLWxSKE4wLyBFGBIu-THSFJCqCDHWrtnEI4WCEzR0-3QNy4l2uSnQtBb0I4z-w4XpNO6Z73EDpJ91JD3EYzQ7SlM28uhmsSwTw8xCClm-VlsNX3pr_SEuuzhWy3gdfKC2DxbNuG9uE11zTEwds6LKGcOaeiAmKHjnnkx0hLQfsIqin2A/s5472/IMG_1088.JPG"
                alt="parque explora">
        </section>

    </div>

    <footer>
        <ul>
            <li><a href="https://www.instagram.com/" target="_blank">Instagram</a></li>
            <li><a href="https://www.whatsapp.com/?lang=es_LA/" target="_blank">WhatsApp</a></li>
            <li><a href="hhttps://twitter.com/?lang=es" target="_blank">X</a></li>
        </ul>
    </footer>

    <script src="js/cerrar.js"></script>
</body>

</html>