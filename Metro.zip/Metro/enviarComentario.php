<?php
include("conexion.php");
session_start();


if(isset($_POST['enviar'])){
    if(
        strlen($_POST['nombre']) >= 1 &&
        strlen($_POST['comentario']) >= 1 
        
        
        ){
            $nombre = trim($_POST['nombre']);
            $comentario = trim($_POST['comentario']);
            $consulta = "INSERT INTO comentarios(nombre, comentario)
                         VALUES('$nombre', '$comentario')";
            $resultado = mysqli_query($conex, $consulta);
            if($resultado){
                header("Location: comentarios.php");
                exit();
                }
        }
    

}
?>
