<?php
include("menu.php");

?>
    <div>
        <section class="comentarios">
            <h2>Escribe y/o lee comentarios</h2>
            <form id="comentarios" action = "enviarComentario.php" method="POST">
                <label>Usuario:</label>
                <br>
                <br>
                <!-- El usuario no debe de ingresarlo, pero lo puse por si acaso -->
                <input type="text" name="nombre" placeholder="Ingresa usuario" id="usuario" >
                <br>
                <br>
                <label>Escribe tu comentario:</label>
                <br>
                <br>
                <textarea name="comentario" id="comentario" placeholder="Ingrese su comentario" rows="10" cols="50"></textarea>
                <br>
                <br>
                <input type="submit" name="enviar" value="Enviar" class="enviar">
            </form>
        </section>
    </div>
    <div>
        <section class="comentarios">
            <h3>Sección de comentarios</h3>
            <p>En este apartado se encontrarán todos los comentarios de los usuarios registrados: </p>
        </section>
    </div>
    
    <footer>
        <ul>
            <li><a href="https://www.instagram.com/" target="_blank">Instagram</a></li>
            <li><a href="https://www.whatsapp.com/?lang=es_LA/" target="_blank">WhatsApp</a></li>
            <li><a href="hhttps://twitter.com/?lang=es" target="_blank">X</a></li>
        </ul>
    </footer>

    <script src="js/cerrar.js"></script>
</body>
</html>