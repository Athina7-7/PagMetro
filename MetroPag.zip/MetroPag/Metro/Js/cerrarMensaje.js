 // Función para cerrar la notificación
 function cerrarMensaje() {
    document.querySelector('.notification-box').style.display = 'none';
}