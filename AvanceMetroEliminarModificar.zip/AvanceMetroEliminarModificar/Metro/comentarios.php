<?php
include("menu.php");

// Verificar si la sesión ya está iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

$usuario = $_SESSION['usuario'];

// Realizar la conexión a la base de datos
include("conexion.php");

// Consulta SQL para seleccionar el nombre del usuario y el comentario
$consulta_comentarios = "SELECT comentarios.idcomentario, registro.nombre AS nombre_usuario, comentarios.comentario
                         FROM comentarios
                         INNER JOIN registro ON comentarios.Id_Nombre = registro.idRegistro";
$resultado_comentarios = mysqli_query($conex, $consulta_comentarios);

$usuario = $_SESSION['usuario'];

?>
    <div>
        <section class="content-wrappe">
            <h2>Escribe y/o lee comentarios</h2>
            <form id="comentarios" action="enviarComentario.php" method="POST">
                <label>Usuario: <?php echo htmlspecialchars($usuario); ?></label>

                <br>
                <br>
                <label>Escribe tu comentario:</label>
                <br>
                <br>
                <textarea name="comentario" id="comentario" style="font-family: Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif; text-align: center; font-size: 20px;" placeholder="Ingrese su comentario" rows="10" cols="50" required autofocus></textarea>
                <br>
                <br>
                <input type="submit" name="enviar" value="Enviar" class="enviar">
            </form>
        </section>
    </div>
    <div>
    <section id="sectionDerecha" style="margin-left: auto; margin-top: -778px; font-family: Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif; text-align: center; font-size: 20px;">
    <h2>Sección de comentarios</h2>
    <p>En este apartado se encontrarán todos los comentarios de los usuarios registrados: </p>
    <?php
    // Verificar si hay comentarios
    if (mysqli_num_rows($resultado_comentarios) > 0) {
        // Iniciar la tabla de comentarios
        echo "<table class='comentarios-table'>";
        echo "<tr><th>Nombre - </th><th> - Comentario - </th><th> - </th><th>Opciones</th></tr>";
        
        // Iterar sobre el resultado de la consulta y mostrar cada comentario con el nombre del usuario en una fila de tabla
        while ($fila = mysqli_fetch_assoc($resultado_comentarios)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($fila['nombre_usuario']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['comentario']) . "</td>";
            echo "<td>    </td>";
            echo "<td><a href='Modificar_comentario.php?idcomentario=".  $fila['idcomentario'] ."' class='btn btn-secondary'>Modificar</a></td>";
            echo "<td><a href='eliminar_comentario.php?idcomentario=".  $fila['idcomentario'] ."' class='btn btn-secondary'>Eliminar</a></td>";
            echo "</tr>";
        }
        
        // Cerrar la tabla de comentarios
        echo "</table>";
    } else {
        echo "<p>No hay comentarios aún.</p>";
    }
    ?>
</section>


    </div>
    
    <footer>
        <ul>
            <li><a href="https://www.instagram.com/" target="_blank">Instagram</a></li>
            <li><a href="https://www.whatsapp.com/?lang=es_LA/" target="_blank">WhatsApp</a></li>
            <li><a href="hhttps://twitter.com/?lang=es" target="_blank">X</a></li>
        </ul>
    </footer>
</body>
</html>
