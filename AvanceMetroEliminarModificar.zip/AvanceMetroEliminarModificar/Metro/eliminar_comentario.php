<?php
require_once 'conexion.php';
session_start();

$sql = "DELETE FROM comentarios WHERE idcomentario = " . $_GET['idcomentario'];
$result = $conex->query($sql);
$conex->close();
if($result) {
    $_SESSION['flash_message'] = "Comentario eliminado";
} else {
    $_SESSION['flash_message'] = "Error al eliminar el comentario";
}

header('LOCATION: comentarios.php');
