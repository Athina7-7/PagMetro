<?php
session_start();
include("conexion.php");

// Verificar si hay un idcomentario en la URL
if(isset($_GET['IdComentario'])) {
    $IdComentario = $_GET['idcomentario'];
    $sql = "DELETE FROM comentarios WHERE IdComentario = $IdComentario";
    if($conex->query($sql)) {
        $_SESSION['flash_message'] = "Comentario eliminado correctamente.";
    } else {
        $_SESSION['flash_message'] = "Error al eliminar el comentario.";
    }
    header('Location: comentario.php');
    exit();
} else {
    header('Location: comentario.php');
    exit();
}
?>
