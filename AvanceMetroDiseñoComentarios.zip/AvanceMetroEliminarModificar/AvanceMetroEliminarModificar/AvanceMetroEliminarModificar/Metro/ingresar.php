<?php
include("conexion.php");

session_start();

if (isset($_POST['Ingresar'])) {
    if (strlen($_POST['usuario']) >= 1 && strlen($_POST['contrasena']) >= 1) {
        $usuario = trim($_POST['usuario']);
        $contrasena = trim($_POST['contrasena']);

        // Consulta para verificar si el usuario está registrado
        $consulta = "SELECT * FROM registro WHERE usuario='$usuario' AND contraseña='$contrasena'";
        $resultado = mysqli_query($conex, $consulta);

        if (mysqli_num_rows($resultado) > 0) {
            // Usuario encontrado, obtener sus datos
            $fila = mysqli_fetch_assoc($resultado);

            // Almacenar el nombre de usuario y idRegistro en la sesión
            $_SESSION['usuario'] = $usuario;
            $_SESSION['idRegistro'] = $fila['idRegistro'];

            // Verificar que idRegistro se almacene correctamente
            print_r($_SESSION); // Añadir esta línea para ver el contenido de la sesión

            if (isset($_SESSION['idRegistro'])) {
                // Redirigir a la página de inicio
                header("Location: index.php");
                exit();
            } else {
                echo "Error: No se pudo almacenar el ID del usuario en la sesión.";
            }
        } else {
            // Usuario no encontrado
            $mensaje = '<div class="notification-box error">
                            <span class="close" onclick="cerrarMensaje()"></span>
                            <h3>Usuario o contraseña incorrectos 401 Unauthorized</h3>
                        </div>';
            echo $mensaje;
        }
    }
}
?>
