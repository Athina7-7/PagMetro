<?php
include("menu.php");

// Verificar si la sesión ya está iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

$usuario = $_SESSION['usuario'];

// Realizar la conexión a la base de datos
include("conexion.php");

// Consulta SQL para seleccionar el nombre del usuario y el comentario
$consulta_comentarios = "SELECT comentarios.idcomentario, registro.nombre AS nombre_usuario, comentarios.comentario
                         FROM comentarios
                         INNER JOIN registro ON comentarios.Id_Nombre = registro.idRegistro";
$resultado_comentarios = mysqli_query($conex, $consulta_comentarios);

$usuario = $_SESSION['usuario'];

?>
<!DOCTYPE html>
<html lang="es">
<he52ad>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comentarios</title>
    <style>
        
        .comentario-burbuja {
            background-color: #d3f0d0; 
            border: 2px solid #339933; 
            border-radius: 10px; 
            padding: 20px; 
            margin-bottom: 30px; 
            clear: both; 
            overflow: hidden; 
            position: relative; 
        }

        .comentario-burbuja strong {
            font-weight: bold; 
            position: absolute; 
            top: 10px; 
            left: 10px; 
        }

        
        .comentario-burbuja p {
            margin: 20px 0 10px 0; 
            text-align: left; 
        }

        .comentario-burbuja a {
            background-color: #4CAF50; 
            color: white; 
            padding: 8px 16px; 
            text-decoration: none; 
            border-radius: 5px; 
            position: absolute; 
            bottom: 10px; 
        }

        .comentario-burbuja a:first-child {
            right: 10px;
        }

        .comentario-burbuja a:last-child {
            right: 100px; 
        }

        .comentario-burbuja a:hover {
            background-color: #45a049; 
        }
    </style>
</head>
<body>
<div>
    <section class="content-wrappe">
        <h2>Escribe y/o lee comentarios</h2>
        <form id="comentarios" action="enviarComentario.php" method="POST">
            <label>Usuario: <?php echo htmlspecialchars($usuario); ?></label>

            <br>
            <br>
            <label>Escribe tu comentario:</label>
            <br>
            <br>
            <textarea name="comentario" id="comentario" style="font-family: Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif; text-align: center; font-size: 20px;" placeholder="Ingrese su comentario" rows="10" cols="50" required autofocus></textarea>
            <br>
            <br>
            <input type="submit" name="enviar" value="Enviar" class="enviar">
        </form>
    </section>
</div>
<div>
    <section id="sectionDerecha" style="margin-left: auto; margin-top: -778px; font-family: Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif; text-align: center; font-size: 20px;">
        <h2>Sección de comentarios</h2>
        <p>En este apartado se encontrarán todos los comentarios de los usuarios registrados: </p>
        <?php
        // Verificar si hay comentarios
        if (mysqli_num_rows($resultado_comentarios) > 0) {
            // Iterar sobre el resultado de la consulta y mostrar cada comentario con el nombre del usuario en una fila de tabla
            while ($fila = mysqli_fetch_assoc($resultado_comentarios)) {
                echo "<div class='comentario-burbuja'>";
                echo "<td><strong>" . htmlspecialchars($fila['nombre_usuario']) . "</strong></td>";
                echo "<td><p>" . htmlspecialchars($fila['comentario']) . "</p></td>";
                echo "<td><a href='Modificar_comentario.php?idcomentario=".  $fila['idcomentario'] ."' class='btn btn-secondary' style='right: 10px;'>Modificar</a></td>";
                echo "<td><a href='eliminar_comentario.php?idcomentario=".  $fila['idcomentario'] ."' class='btn btn-secondary' style='right: 120px;'>Eliminar</a></td>";
                echo "</div>";
            }
        } else {
            echo "<p>No hay comentarios aún.</p>";
        }
        ?>
    </section>
</div>

<footer>
    <ul>
        <li><a href="https://www.instagram.com/" target="_blank">Instagram</a></li>
        <li><a href="https://www.whatsapp.com/?lang=es_LA/" target="_blank">WhatsApp</a></li>
        <li><a href="hhttps://twitter.com/?lang=es" target="_blank">X</a></li>
    </ul>
</footer>
</body>
</html>
